# AX 증권 (AI 주식 종목 분석 대시보드)

풀스택 세미프로젝트 주제 4번 **"AI 주식 종목 분석 대시보드"** 를 토스증권 화면 구성에 맞춰 만든 프로젝트입니다.
React(화면) + FastAPI(API) + SQLAlchemy(DB) 구조이고, 지금은 **샘플 데이터**로 동작합니다.

## 화면 구성

로그인 왼쪽의 **투자성향**(안정형/보통/공격형, 기본 보통)을 바꾸면 추천 종목과 상세 화면의 "내 성향이라면?" 설명이 달라지고, 선택은 브라우저에 기억돼요. 로그인 자리 쪽은 나중에 내 정보가 들어갈 수 있게 비워 뒀어요.


| 화면 | 내용 |
| --- | --- |
| 홈 `/` | 하얀 바탕. 왼쪽 메뉴, 가운데 **관심 주식** 카드(주가 그래프 대신 "1년 중 가격 위치"·기간별 수익률·전문가 의견) · **전문가 투자의견** · **종목 비교**(카드의 "+ 비교"로 2~3개 선택, 카드는 6개까지 보이고 "더 보기"로 펼침) (실시간 랭킹은 뺐어요), 오른쪽에 **관심 주식** 아래로 **추천 종목** |
| 종목 상세 `/stock/:code` | **한눈에 보기**(3줄 요약, 신호등 4개, 가격 위치, 기간별 수익, "1년 전에 샀다면?", 오늘 분위기, 누가 사고 있나요?, 전문가 의견, 용어 사전) · 차트·호가·주문 · 종목정보 · 뉴스·공시 |

- **검색창**: 위쪽 검색창에서 종목명·종목코드로 검색하고, `Alt+K` 로 바로 이동합니다. 결과를 누르면 종목 상세로 갑니다.
- **전문가 투자의견**: 종목 카드나 랭킹 행을 누르면 홈 아래쪽에 열립니다. 종합 점수 게이지, 적극매수 · 매수 · 중립 · 매도 · 적극매도 의견 수, 의견 분포, 평균 목표주가와 상승여력을 보여줍니다.
- **추천 종목**: 전문가 투자의견 점수가 높은 순서입니다.

관심 종목 규칙
- 처음에는 **비어 있고**, 하트를 눌러야 가운데 "관심 주식" 카드와 오른쪽 관심 주식 패널에 채워집니다.
- 종목 이름 옆 작은 표시는 `관심없음` ↔ `관심` 으로 바뀌며, 하트와 같은 상태입니다.
- 브라우저마다 임시 ID(`X-Client-Id`)로 구분해서 서버(DB)에 저장합니다. 로그인은 아직 없습니다.

## 실행 방법

터미널 2개가 필요합니다.

```bash
# 1) 백엔드  (http://localhost:8000, API 문서: /docs)
cd backend
python -m venv .venv
.venv\Scripts\activate          # macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

```bash
# 2) 프론트엔드  (http://localhost:5173)
cd frontend
npm install
npm run dev
```

처음 실행하면 `backend/stock.db`(SQLite)가 만들어지고 샘플 데이터가 자동으로 들어갑니다. 예전 버전의 `stock.db`가 있어도 새 `consensus` 테이블은 자동으로 만들어져 채워집니다.
데이터를 다시 만들고 싶으면 서버를 끄고 `stock.db` 파일을 지운 뒤 다시 켜세요.
PostgreSQL을 쓰려면 `backend/.env.example` 을 참고해서 `DATABASE_URL` 환경변수를 지정합니다.

## 폴더 구조

```
backend/app
  main.py        앱 시작, 테이블 생성, 샘플 데이터 입력, 라우터 연결
  database.py    DB 연결 (SQLite 기본, DATABASE_URL로 변경)
  models.py      테이블: stocks, candles, market_indices, news, investors, watchlist, consensus
  schemas.py     API 응답 형태 (Pydantic)
  seed.py        샘플 데이터 (현재는 스크린샷 값 기준 + 난수 일봉)
  analysis.py    "왜 올랐을까/떨어졌을까" 분석 (규칙 기반)
  dashboard.py    초보자용 한눈에 보기 데이터(신호등·시뮬레이션) 계산
  opinion.py     전문가 의견 점수·라벨 계산 (5점 척도 → 0~100점)
  routers/       market.py, stocks.py, watchlist.py
frontend/src
  api.js         백엔드 호출 함수 모음
  hooks/         useWatchlist (관심 종목 상태)
  components/    CandleChart, StockCard, Sparkline, OpinionPanel, RankingTable, WatchlistSidebar, HeartButton ...
  pages/         Home, StockPage
```

## API

| 메서드 | 경로 | 설명 |
| --- | --- | --- |
| GET | `/api/stocks?market=all\|kr\|us&sort=value\|volume\|rise\|fall\|cap&q=` | 종목 순위·검색 |
| GET | `/api/stocks/recommended?market=&limit=&style=` | 추천 종목(전문가 의견 점수순). style: safe(안정형)·normal(보통, 기본)·bold(공격형) — 최근 60일 변동성으로 나눠요 |
| GET | `/api/stocks/insights?codes=a,b` | 카드용 요약(1년 가격 위치, 기간별 수익률, 전문가 의견) |
| GET | `/api/stocks/{code}` | 종목 상세(1일·52주 범위, 거래대금 순위) |
| GET | `/api/stocks/{code}/opinion` | 전문가 투자의견(의견 수, 점수, 목표주가) |
| GET | `/api/stocks/{code}/dashboard` | 초보자용 한눈에 보기(요약 문장, 신호등, 시뮬레이션 등) |
| GET | `/api/stocks/{code}/candles?interval=D\|W\|M&limit=` | 일·주·월봉 |
| GET | `/api/stocks/{code}/analysis` | AI 분석(현재는 규칙 기반) |
| GET | `/api/stocks/{code}/news` · `/investors` | 뉴스, 투자자별 순매수 |
| GET | `/api/watchlist` | 내 관심 종목 (헤더 `X-Client-Id` 필요) |
| PUT / DELETE | `/api/watchlist/{code}` | 관심 추가 / 해제 |

## 주제 문서의 수행 절차와 연결

주제 문서의 흐름: 데이터 수집 → 가공·저장 → RAG/LLM 분석 → 인사이트 → 대시보드 → FastAPI·React 통합

| 단계 | 현재 상태 | 다음에 할 일 |
| --- | --- | --- |
| ① 데이터 수집 | `seed.py` 샘플 | pykrx·yfinance·공공데이터 API로 일봉·재무 수집 스크립트 작성 |
| ② 가공·저장 | SQLAlchemy 모델 완성 | Pandas 전처리, PostgreSQL 전환, 재무 테이블(PER·PBR·매출·영업이익) 추가 |
| ③ RAG/LLM | 없음 | 뉴스·공시를 Vector DB(Chroma)에 저장, LangChain으로 검색 |
| ④ 인사이트 | `analysis.py` 규칙 기반 | `build_analysis()` 의 reasons 를 LLM 설명으로 교체 (`mode="llm"`) |
| ⑤ 대시보드 | 홈·상세 화면 완성 | 재무 차트, 종목 비교 |
| ⑥ 통합 | FastAPI ↔ React 연결 | 로그인, 주문(모의투자) |

`analysis.py` 의 설명처럼 **계산은 SQL·코드로 하고, LLM은 그 결과를 설명만** 하게 만드는 구조를 권장합니다.

## 알아둘 점
- 시세·차트·호가·뉴스·분석·전문가 의견 수와 목표주가는 모두 샘플입니다. 호가와 주문 화면은 모양만 있고 실제 주문은 되지 않습니다.
- 토스증권의 로고·이름은 쓰지 않았습니다. 화면 구성만 참고했고, 이름 `AX 증권` 은 바꿔도 됩니다.
