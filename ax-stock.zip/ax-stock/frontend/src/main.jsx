import React from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter } from 'react-router-dom'
import App from './App.jsx'
import { ProfileProvider } from './hooks/useProfile.jsx'
import { WatchlistProvider } from './hooks/useWatchlist.jsx'
import './styles.css'

createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <BrowserRouter>
      <ProfileProvider>
        <WatchlistProvider>
          <App />
        </WatchlistProvider>
      </ProfileProvider>
    </BrowserRouter>
  </React.StrictMode>,
)
