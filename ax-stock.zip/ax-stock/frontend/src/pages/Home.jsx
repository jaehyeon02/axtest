import { useEffect, useMemo, useRef, useState } from 'react'
import { api } from '../api.js'
import Compare from '../components/Compare.jsx'
import OpinionPanel from '../components/OpinionPanel.jsx'
import RecommendList from '../components/RecommendList.jsx'
import StockCard from '../components/StockCard.jsx'
import WatchlistSidebar from '../components/WatchlistSidebar.jsx'
import { useWatchlist } from '../hooks/useWatchlist.jsx'

const SIDE = [
  ['top', '증권 홈'],
  ['watch-cards', '관심 주식'],
  ['recommend', '추천 종목'],
  ['compare', '종목 비교'],
  ['opinion', '전문가 의견'],
]

export default function Home() {
  const { items: watch } = useWatchlist()
  const [insights, setInsights] = useState({})
  const [selected, setSelected] = useState(null)
  const [cmp, setCmp] = useState([])
  const [showAll, setShowAll] = useState(false)
  const [cmpFull, setCmpFull] = useState(false)
  const opinionRef = useRef(null)

  // 관심 주식 카드에 보일 요약(1년 가격 위치, 기간별 수익률). 아직 못 받은 종목만 요청해요.
  const watchCodes = useMemo(() => watch.map((s) => s.code), [watch])
  useEffect(() => {
    const missing = watchCodes.filter((c) => !insights[c])
    if (missing.length) api.insights(missing).then((m) => setInsights((prev) => ({ ...prev, ...m }))).catch(() => {})
  }, [watchCodes]) // eslint-disable-line react-hooks/exhaustive-deps

  // 종목을 고르면 아래 투자의견이 화면에 보이도록 부드럽게 이동
  useEffect(() => {
    if (selected) opinionRef.current?.scrollIntoView({ behavior: 'smooth', block: 'nearest' })
  }, [selected])

  // 비교 목록: 관심에서 빠진 종목은 자동으로 빼고, 최대 3개까지만 담아요.
  useEffect(() => {
    setCmp((c) => (c.every((x) => watchCodes.includes(x)) ? c : c.filter((x) => watchCodes.includes(x))))
  }, [watchCodes])
  const toggleCmp = (code) => {
    setCmpFull(false)
    setCmp((c) => {
      if (c.includes(code)) return c.filter((x) => x !== code)
      if (c.length >= 3) {
        setCmpFull(true)
        return c
      }
      return [...c, code]
    })
  }
  const cmpStocks = cmp.map((c) => watch.find((s) => s.code === c)).filter(Boolean)

  const go = (id) => document.getElementById(id)?.scrollIntoView({ behavior: 'smooth', block: 'start' })

  return (
    <main className="home with-side" id="top">
      <nav className="side-nav" aria-label="홈 메뉴">
        {SIDE.map(([id, name], i) => (
          <button key={id} type="button" className={i === 0 ? 'on' : ''} onClick={() => go(id)}>
            {name}
          </button>
        ))}
      </nav>

      <div className="home-main">
        <section id="watch-cards" className="block">
          <div className="sec-head">
            <h2>관심 주식</h2>
            <span className="mute small">하트를 누른 종목이 여기에 모여요 · 카드를 누르면 쉬운 설명이 열려요</span>
          </div>
          {watch.length === 0 ? (
            <div className="cards-empty">
              <b>아직 관심 주식이 없어요</b>
              <span>오른쪽 추천 종목이나 검색으로 찾아서 하트를 눌러 담아보세요.</span>
            </div>
          ) : (
            <div className="cards">
              {(showAll ? watch : watch.slice(0, 6)).map((s) => (
                <StockCard
                  key={s.code}
                  stock={s}
                  insight={insights[s.code]}
                  selected={selected === s.code}
                  onSelect={setSelected}
                  comparing={cmp.includes(s.code)}
                  onCompare={toggleCmp}
                />
              ))}
            </div>
          )}
          {watch.length > 6 && (
            <button type="button" className="more" onClick={() => setShowAll(!showAll)}>
              {showAll ? '접기' : `더 보기 (${watch.length - 6}개)`}
            </button>
          )}
        </section>

        <section id="compare" className="block">
          <div className="sec-head">
            <h2>종목 비교</h2>
            <span className="mute small">카드의 "+ 비교"를 눌러 2~3개를 나란히 보세요</span>
          </div>
          {cmpFull && <p className="cmp-warn small">한 번에 3개까지 비교할 수 있어요. 하나를 빼고 골라 주세요.</p>}
          {cmpStocks.length >= 2 ? (
            <Compare stocks={cmpStocks} onRemove={toggleCmp} />
          ) : (
            <div className="cards-empty">
              <b>{cmpStocks.length === 1 ? `${cmpStocks[0].name} 외에 하나만 더 골라 보세요` : '비교할 종목을 골라 보세요'}</b>
              <span>관심 주식 카드의 "+ 비교"를 2개 이상 누르면 수익률·전문가 의견을 한 표로 볼 수 있어요.</span>
            </div>
          )}
        </section>

        <section id="opinion" className="block" ref={opinionRef}>
          <div className="sec-head">
            <h2>전문가 투자의견</h2>
            <span className="mute small">적극매수 · 매수 · 중립 · 매도 · 적극매도</span>
          </div>
          {selected ? (
            <div className="card opinion-wrap">
              <OpinionPanel code={selected} />
            </div>
          ) : (
            <div className="cards-empty">
              <b>종목을 눌러보세요</b>
              <span>카드나 오른쪽 추천 종목을 누르면 전문가들의 투자의견이 여기에 나와요.</span>
            </div>
          )}
        </section>
      </div>

      <div className="right-col">
        <WatchlistSidebar onSelect={setSelected} selected={selected} />
        <RecommendList onSelect={setSelected} selected={selected} />
      </div>
    </main>
  )
}
