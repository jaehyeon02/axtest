import { useEffect, useMemo, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { api } from '../api.js'
import CandleChart from '../components/CandleChart.jsx'
import Dashboard from '../components/Dashboard.jsx'
import { HeartButton, Logo, WatchChip } from '../components/HeartButton.jsx'
import WatchlistSidebar from '../components/WatchlistSidebar.jsx'
import { eok, rate, shares, tickSize, tone, won } from '../format.js'

const TABS = ['한눈에 보기', '차트 · 호가', '종목정보', '뉴스 · 공시']
const INTERVALS = [
  ['D', '일'],
  ['W', '주'],
  ['M', '월'],
]
// 기간 버튼 → 일봉 기준 개수. 주봉·월봉일 때는 나눠서 사용해요.
const PERIODS = [
  ['1달', 22],
  ['3달', 66],
  ['6달', 130],
  ['1년', 260],
  ['전체', 9999],
]

// 호가 창: 현재가 위아래 10단계. 실제 호가 API를 연결하기 전까지 쓰는 예시 값이에요.
function makeOrderbook(stock) {
  const tick = tickSize(stock.price)
  let seed = [...stock.code].reduce((a, ch) => (a * 31 + ch.charCodeAt(0)) >>> 0, 7)
  const rnd = () => ((seed = (seed * 1664525 + 1013904223) >>> 0) / 4294967296)
  const base = Math.max(10, Math.round(stock.volume / 400))
  const level = () => Math.round(base * (0.3 + rnd() * 1.4))
  const asks = Array.from({ length: 10 }, (_, k) => ({ price: stock.price + (10 - k) * tick, qty: level() }))
  const bids = Array.from({ length: 10 }, (_, k) => ({ price: stock.price - (k + 1) * tick, qty: level() }))
  return { asks, bids, max: Math.max(...asks.map((a) => a.qty), ...bids.map((b) => b.qty)) }
}

export default function StockPage() {
  const { code } = useParams()
  const [stock, setStock] = useState(null)
  const [error, setError] = useState(false)
  const [tab, setTab] = useState(TABS[0])
  const [unit, setUnit] = useState('D')
  const [period, setPeriod] = useState('1년')
  const [count, setCount] = useState(260)
  const [candles, setCandles] = useState([])
  const [news, setNews] = useState([])
  const [investors, setInvestors] = useState([])
  const [priceInput, setPriceInput] = useState('')
  const [qty, setQty] = useState('')
  const [orderType, setOrderType] = useState('limit')

  useEffect(() => {
    setError(false)
    setStock(null)
    Promise.all([api.stock(code), api.news(code), api.investors(code)])
      .then(([s, n, inv]) => {
        setStock(s)
        setNews(n)
        setInvestors(inv)
        setPriceInput(String(Math.round(s.price)))
      })
      .catch(() => setError(true))
  }, [code])

  useEffect(() => {
    api.candles(code, unit, 600).then(setCandles).catch(() => {})
  }, [code, unit])

  const pickPeriod = (name, days) => {
    setPeriod(name)
    setCount(unit === 'D' ? days : unit === 'W' ? Math.ceil(days / 5) : Math.ceil(days / 21))
  }
  const pickInterval = (key) => {
    setUnit(key)
    const days = PERIODS.find(([n]) => n === period)?.[1] ?? 260
    setCount(key === 'D' ? days : key === 'W' ? Math.ceil(days / 5) : Math.ceil(days / 21))
  }

  const book = useMemo(() => (stock ? makeOrderbook(stock) : null), [stock])

  if (error) {
    return (
      <main className="detail">
        <p className="table-empty">종목 정보를 불러오지 못했어요. <Link to="/">홈으로 돌아가기</Link></p>
      </main>
    )
  }
  if (!stock) return <main className="detail"><p className="panel-loading">불러오는 중…</p></main>

  const numPrice = Number(priceInput.replace(/,/g, '')) || 0
  const total = numPrice * (Number(qty) || 0)

  return (
    <main className="home">
      <div className="home-main">
        <section className="stock-head">
          <div className="stock-title">
            <Logo stock={stock} size={40} />
            <div>
              <h1>
                {stock.name} <span className="mute num small">{stock.code}</span> <WatchChip stock={stock} />
              </h1>
              <div className="num price">
                {won(stock.price)}{' '}
                <span className={`small ${tone(stock.change_rate)}`}>
                  전일 대비 {won(Math.abs(stock.price - stock.prev_close))} ({rate(stock.change_rate)})
                </span>
              </div>
            </div>
            <HeartButton stock={stock} />
          </div>
          <dl className="stats">
            <div><dt>1일 범위</dt><dd className="num">{won(stock.day_low)} ~ {won(stock.day_high)}</dd></div>
            <div><dt>52주 범위</dt><dd className="num">{won(stock.week52_low)} ~ {won(stock.week52_high)}</dd></div>
            <div><dt>거래대금</dt><dd className="num">{eok(stock.trade_value)} ({stock.value_rank}위)</dd></div>
            <div><dt>시가총액</dt><dd className="num">{eok(stock.market_cap)}</dd></div>
          </dl>
        </section>

        <div className="tabs" role="tablist">
          {TABS.map((t) => (
            <button key={t} type="button" role="tab" aria-selected={tab === t} onClick={() => setTab(t)}>
              {t}
            </button>
          ))}
        </div>

        {tab === TABS[0] && <Dashboard code={code} stock={stock} />}

        {tab === TABS[1] && (
          <div className="detail-grid">
            <section className="card chart-card">
              <div className="toolbar">
                <div className="seg" role="group" aria-label="차트 단위">
                  {INTERVALS.map(([k, label]) => (
                    <button key={k} type="button" aria-pressed={unit === k} onClick={() => pickInterval(k)}>
                      {label}
                    </button>
                  ))}
                </div>
                <div className="seg" role="group" aria-label="기간">
                  {PERIODS.map(([name, days]) => (
                    <button key={name} type="button" aria-pressed={period === name} onClick={() => pickPeriod(name, days)}>
                      {name}
                    </button>
                  ))}
                </div>
                <span className="mute small">휠: 확대·축소 / 드래그: 이동</span>
              </div>
              <CandleChart candles={candles} height={440} count={count} onCountChange={setCount} />
            </section>

            <section className="card book" aria-label="호가">
              <h2>호가 <span className="badge">예시</span></h2>
              <ul>
                {book.asks.map((a) => (
                  <li key={a.price} className="ask">
                    <i style={{ width: `${(a.qty / book.max) * 100}%` }} />
                    <span className="num">{a.qty.toLocaleString('ko-KR')}</span>
                    <span className="num down">{a.price.toLocaleString('ko-KR')}</span>
                  </li>
                ))}
                <li className="now num"><span>{won(stock.price)}</span><span className={tone(stock.change_rate)}>{rate(stock.change_rate)}</span></li>
                {book.bids.map((b) => (
                  <li key={b.price} className="bid">
                    <i style={{ width: `${(b.qty / book.max) * 100}%` }} />
                    <span className="num up">{b.price.toLocaleString('ko-KR')}</span>
                    <span className="num">{b.qty.toLocaleString('ko-KR')}</span>
                  </li>
                ))}
              </ul>
            </section>

            <section className="card order" aria-label="주문">
              <h2>일반주문</h2>
              <div className="seg full" role="group" aria-label="주문 방식">
                <button type="button" aria-pressed={orderType === 'limit'} onClick={() => setOrderType('limit')}>지정가</button>
                <button type="button" aria-pressed={orderType === 'market'} onClick={() => setOrderType('market')}>시장가</button>
              </div>
              <label htmlFor="order-price">구매 가격</label>
              <input id="order-price" className="num" value={orderType === 'market' ? '시장가' : priceInput}
                disabled={orderType === 'market'} inputMode="numeric"
                onChange={(e) => setPriceInput(e.target.value.replace(/[^0-9,]/g, ''))} />
              <label htmlFor="order-qty">수량</label>
              <input id="order-qty" className="num" value={qty} inputMode="numeric" placeholder="수량 입력"
                onChange={(e) => setQty(e.target.value.replace(/\D/g, ''))} />
              <div className="quick">
                {[1, 5, 10, 100].map((n) => (
                  <button key={n} type="button" onClick={() => setQty(String((Number(qty) || 0) + n))}>+{n}주</button>
                ))}
              </div>
              <div className="total"><span>총 주문 금액</span><b className="num">{total ? won(total) : '-'}</b></div>
              <button type="button" className="buy" disabled title="로그인·주문 기능은 추후 구현 예정">
                로그인하고 구매하기
              </button>
              <p className="mute small">주문 기능은 아직 연결되지 않았어요.</p>
            </section>

            <section className="card investors">
              <h2>개인 · 외국인 · 기관 순매수 <span className="mute small">(주)</span></h2>
              <div className="scroll">
                <table>
                  <thead><tr><th>일자</th><th>개인</th><th>외국인</th><th>기관</th></tr></thead>
                  <tbody>
                    {investors.map((r) => (
                      <tr key={r.day}>
                        <td className="num">{r.day}</td>
                        {[r.individual, r.foreign, r.institution].map((v, i) => (
                          <td key={i} className={`num ${tone(v)}`}>{shares(v)}</td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </section>
          </div>
        )}

        {tab === TABS[2] && (
          <section className="card info">
            <h2>종목정보</h2>
            <dl className="stats wide">
              <div><dt>종목명</dt><dd>{stock.name}</dd></div>
              <div><dt>종목코드</dt><dd className="num">{stock.code}</dd></div>
              <div><dt>시장</dt><dd>{stock.market === 'kr' ? '국내' : '해외'}</dd></div>
              <div><dt>산업</dt><dd>{stock.sector ?? '-'}</dd></div>
              <div><dt>시가총액</dt><dd className="num">{eok(stock.market_cap)}</dd></div>
              <div><dt>거래량</dt><dd className="num">{stock.volume.toLocaleString('ko-KR')}주</dd></div>
            </dl>
            <p className="mute small">PER·PBR·매출·영업이익 같은 재무 지표는 데이터 수집 단계가 끝나면 이곳에 추가해요.</p>
          </section>
        )}

        {tab === TABS[3] && (
          <section className="card info">
            <h2>뉴스 · 공시</h2>
            <ul className="news">
              {news.map((n) => (
                <li key={n.id}>
                  <span className={`sent ${n.sentiment}`}>{n.sentiment === 'pos' ? '호재' : n.sentiment === 'neg' ? '악재' : '일반'}</span>
                  <div>
                    <div>{n.title}</div>
                    <span className="mute small">{n.source} · {n.published_at.replace('T', ' ').slice(0, 16)}</span>
                  </div>
                </li>
              ))}
            </ul>
          </section>
        )}
      </div>
      <WatchlistSidebar />
    </main>
  )
}
