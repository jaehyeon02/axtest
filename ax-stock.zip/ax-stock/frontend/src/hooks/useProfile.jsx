import { createContext, useCallback, useContext, useMemo, useState } from 'react'

// 투자성향: 안정형 / 보통 / 공격형. 기본값은 "보통"이고, 브라우저에 기억해 둬요.
export const STYLES = {
  safe: { name: '안정형', desc: '잃지 않는 게 먼저예요. 가격이 덜 출렁이는 종목을 보여줘요.' },
  normal: { name: '보통', desc: '안정과 수익을 균형 있게 봐요. 모든 종목에서 골라줘요.' },
  bold: { name: '공격형', desc: '큰 수익을 노려요. 가격이 많이 움직이는 종목을 보여줘요.' },
}
const KEY = 'ax-invest-style'
const Ctx = createContext({ style: 'normal', setStyle: () => {} })

function read() {
  try {
    const v = localStorage.getItem(KEY)
    return v in STYLES ? v : 'normal'
  } catch {
    return 'normal'
  }
}

export function ProfileProvider({ children }) {
  const [style, set] = useState(read)
  const setStyle = useCallback((v) => {
    set(v)
    try {
      localStorage.setItem(KEY, v)
    } catch {
      /* 저장이 막힌 브라우저에서는 이번 방문 동안만 유지돼요 */
    }
  }, [])
  const value = useMemo(() => ({ style, setStyle }), [style, setStyle])
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>
}

export const useProfile = () => useContext(Ctx)
