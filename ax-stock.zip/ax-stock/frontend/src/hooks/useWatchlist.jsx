import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react'
import { api } from '../api.js'

const WatchlistContext = createContext(null)

// 관심 종목 상태를 앱 전체에서 같이 씁니다. 처음에는 비어 있고, 하트를 눌러야 채워져요.
export function WatchlistProvider({ children }) {
  const [items, setItems] = useState([]) // 서버에 저장된 관심 종목(종목 정보 포함)
  const [loaded, setLoaded] = useState(false)

  const reload = useCallback(
    () =>
      api
        .watchlist()
        .then(setItems)
        .catch(() => {})
        .finally(() => setLoaded(true)),
    [],
  )
  useEffect(() => {
    reload()
  }, [reload])

  const codes = useMemo(() => new Set(items.map((s) => s.code)), [items])

  const toggle = useCallback(
    async (stock) => {
      const on = codes.has(stock.code)
      // 화면은 먼저 바꾸고(낙관적 업데이트), 서버 결과로 다시 맞춥니다.
      setItems((prev) => (on ? prev.filter((s) => s.code !== stock.code) : [...prev, stock]))
      try {
        await (on ? api.removeWatch(stock.code) : api.addWatch(stock.code))
      } finally {
        reload()
      }
    },
    [codes, reload],
  )

  const value = useMemo(() => ({ items, codes, loaded, toggle }), [items, codes, loaded, toggle])
  return <WatchlistContext.Provider value={value}>{children}</WatchlistContext.Provider>
}

export const useWatchlist = () => useContext(WatchlistContext)
