import { Route, Routes } from 'react-router-dom'
import Header from './components/Header.jsx'
import Home from './pages/Home.jsx'
import StockPage from './pages/StockPage.jsx'

export default function App() {
  return (
    <>
      <Header />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/stock/:code" element={<StockPage />} />
      </Routes>
      <p className="disclaimer">
        표시된 시세와 분석은 개발용 샘플 데이터예요. 실제 투자 판단에 사용하지 마세요.
      </p>
    </>
  )
}
