import { useEffect, useMemo, useRef, useState } from 'react'
import { rate, tone } from '../format.js'

// 이동평균선: [기간, 색]
const MAS = [
  [5, '#2fbf71'],
  [20, '#f5a524'],
  [60, '#e5484d'],
  [120, '#a259ff'],
]

function movingAverage(values, n) {
  const out = new Array(values.length).fill(null)
  let sum = 0
  for (let i = 0; i < values.length; i++) {
    sum += values[i]
    if (i >= n) sum -= values[i - n]
    if (i >= n - 1) out[i] = sum / n
  }
  return out
}

const fmt = (v) => Math.round(v).toLocaleString('ko-KR')

/**
 * 캔들 차트 (canvas로 직접 그림).
 *  - 마우스를 올리면 십자선과 시가·고가·저가·종가가 나와요.
 *  - 휠로 확대/축소, 드래그로 좌우 이동.
 *  - mini=true 이면 이동평균선 없이 작게 그려요.
 */
export default function CandleChart({ candles, height = 420, mini = false, count, onCountChange }) {
  const wrap = useRef(null)
  const cv = useRef(null)
  const drag = useRef(null)
  const [width, setWidth] = useState(600)
  const [innerCount, setInnerCount] = useState(mini ? 80 : 120)
  const [offset, setOffset] = useState(0) // 오른쪽 끝에서 몇 개 왼쪽으로 이동했는지
  const [hover, setHover] = useState(null) // { i, x, y }

  const visibleCount = Math.max(20, Math.min(count ?? innerCount, Math.max(candles.length, 20)))
  const setCount = (fn) => {
    const next = typeof fn === 'function' ? fn(visibleCount) : fn
    onCountChange ? onCountChange(next) : setInnerCount(next)
  }

  const closes = useMemo(() => candles.map((c) => c.c), [candles])
  const mas = useMemo(() => MAS.map(([n]) => movingAverage(closes, n)), [closes])

  const end = Math.max(Math.min(candles.length, candles.length - offset), 1)
  const start = Math.max(0, end - visibleCount)
  const vis = candles.slice(start, end)

  const padR = mini ? 56 : 72
  const axisH = 22
  const volH = Math.round(height * 0.2)
  const gap = 8
  const priceH = height - axisH - volH - gap
  const plotW = width - padR
  const slot = plotW / visibleCount

  // 컨테이너 너비를 따라가요.
  useEffect(() => {
    if (!wrap.current) return
    const ro = new ResizeObserver(([e]) => setWidth(Math.max(240, Math.floor(e.contentRect.width))))
    ro.observe(wrap.current)
    return () => ro.disconnect()
  }, [])

  // 데이터가 바뀌면 처음 위치로
  useEffect(() => setOffset(0), [candles])

  // 휠 확대/축소 (preventDefault를 쓰려면 passive:false 로 직접 등록해야 해요)
  useEffect(() => {
    const el = cv.current
    if (!el) return
    const onWheel = (e) => {
      e.preventDefault()
      setCount((c) => Math.max(20, Math.min(candles.length, c + (e.deltaY > 0 ? 10 : -10))))
    }
    el.addEventListener('wheel', onWheel, { passive: false })
    return () => el.removeEventListener('wheel', onWheel)
  })

  useEffect(() => {
    const c = cv.current
    if (!c || vis.length === 0) return
    const dpr = window.devicePixelRatio || 1
    c.width = width * dpr
    c.height = height * dpr
    const g = c.getContext('2d')
    g.setTransform(dpr, 0, 0, dpr, 0, 0)
    g.clearRect(0, 0, width, height)

    const css = getComputedStyle(c) // .chart 안에서 정한 흰 배경용 색을 읽어요
    const col = (n) => css.getPropertyValue(n).trim()
    const [cUp, cDown, cLine, cMute, cAccent] = ['--up', '--down', '--line', '--mute', '--accent'].map(col)

    const hi = Math.max(...vis.map((d) => d.h))
    const lo = Math.min(...vis.map((d) => d.l))
    const pad = (hi - lo) * 0.06 || 1
    const top = 8
    const y = (v) => top + ((hi + pad - v) / (hi - lo + pad * 2)) * (priceH - top)
    const maxV = Math.max(...vis.map((d) => d.v)) || 1
    const volBase = height - axisH
    const x = (i) => plotW - (vis.length - i) * slot + slot / 2

    g.font = '11px "IBM Plex Sans KR", system-ui, sans-serif'
    g.textBaseline = 'middle'

    // 가격 눈금
    g.lineWidth = 1
    for (let k = 0; k < 5; k++) {
      const v = hi + pad - ((hi - lo + pad * 2) * k) / 4
      const yy = Math.round(y(v)) + 0.5
      g.strokeStyle = cLine
      g.beginPath()
      g.moveTo(0, yy)
      g.lineTo(plotW, yy)
      g.stroke()
      g.fillStyle = cMute
      g.textAlign = 'left'
      g.fillText(fmt(v), plotW + 6, yy)
    }

    // 날짜 눈금
    const every = Math.max(1, Math.ceil(80 / slot))
    g.textAlign = 'center'
    g.fillStyle = cMute
    vis.forEach((d, i) => {
      if ((vis.length - 1 - i) % every === 0) {
        const t = String(d.t)
        g.fillText(t.slice(2, 7).replace('-', '.') + (every > 20 ? '' : '.' + t.slice(8)), x(i), height - axisH / 2)
      }
    })

    // 거래량
    const bw = Math.max(1, slot * 0.7)
    vis.forEach((d, i) => {
      g.globalAlpha = 0.5
      g.fillStyle = d.c >= d.o ? cUp : cDown
      const vh = (d.v / maxV) * (volH - 6)
      g.fillRect(x(i) - bw / 2, volBase - vh, bw, vh)
    })
    g.globalAlpha = 1

    // 캔들
    vis.forEach((d, i) => {
      const c0 = d.c >= d.o ? cUp : cDown
      g.strokeStyle = c0
      g.fillStyle = c0
      g.beginPath()
      g.moveTo(Math.round(x(i)) + 0.5, y(d.h))
      g.lineTo(Math.round(x(i)) + 0.5, y(d.l))
      g.stroke()
      const bt = y(Math.max(d.o, d.c))
      g.fillRect(x(i) - bw / 2, bt, bw, Math.max(1, Math.abs(y(d.o) - y(d.c))))
    })

    // 이동평균선
    if (!mini) {
      MAS.forEach(([, color], m) => {
        g.strokeStyle = color
        g.lineWidth = 1.2
        g.beginPath()
        let started = false
        vis.forEach((_, i) => {
          const v = mas[m][start + i]
          if (v == null) return
          started ? g.lineTo(x(i), y(v)) : g.moveTo(x(i), y(v))
          started = true
        })
        g.stroke()
      })
      g.lineWidth = 1
    }

    // 현재가 선·태그 (맨 오른쪽 끝을 보고 있을 때만)
    if (offset === 0) {
      const last = vis[vis.length - 1]
      const ly = y(last.c)
      g.setLineDash([3, 3])
      g.strokeStyle = last.c >= last.o ? cUp : cDown
      g.beginPath()
      g.moveTo(0, ly)
      g.lineTo(plotW, ly)
      g.stroke()
      g.setLineDash([])
      g.fillStyle = last.c >= last.o ? cUp : cDown
      g.fillRect(plotW + 1, ly - 9, padR - 1, 18)
      g.fillStyle = '#fff'
      g.textAlign = 'left'
      g.fillText(fmt(last.c), plotW + 6, ly)
    }

    // 십자선
    if (hover && hover.i >= 0 && hover.i < vis.length) {
      const hx = x(hover.i)
      g.setLineDash([3, 3])
      g.strokeStyle = cMute
      g.beginPath()
      g.moveTo(Math.round(hx) + 0.5, 0)
      g.lineTo(Math.round(hx) + 0.5, height - axisH)
      g.moveTo(0, hover.y)
      g.lineTo(plotW, hover.y)
      g.stroke()
      g.setLineDash([])
      if (hover.y < priceH) {
        const price = hi + pad - ((hover.y - top) / (priceH - top)) * (hi - lo + pad * 2)
        g.fillStyle = cAccent
        g.fillRect(plotW + 1, hover.y - 9, padR - 1, 18)
        g.fillStyle = '#fff'
        g.textAlign = 'left'
        g.fillText(fmt(price), plotW + 6, hover.y)
      }
    }
  }, [vis, width, height, mini, hover, offset, mas, start, slot, plotW, priceH, volH])

  const onMove = (e) => {
    const r = cv.current.getBoundingClientRect()
    const px = e.clientX - r.left
    const py = e.clientY - r.top
    if (drag.current) {
      const moved = Math.round((px - drag.current.x) / slot)
      setOffset(Math.max(0, Math.min(candles.length - 20, drag.current.offset + moved)))
      return
    }
    const fromRight = Math.floor((plotW - px) / slot)
    const i = vis.length - 1 - fromRight
    setHover(px > plotW || i < 0 || i >= vis.length || py > height - axisH ? null : { i, y: py })
  }

  const shown = hover ? vis[hover.i] : vis[vis.length - 1]
  const globalIdx = shown ? start + (hover ? hover.i : vis.length - 1) : 0
  const prevClose = globalIdx > 0 ? candles[globalIdx - 1].c : shown?.o
  const chg = shown && prevClose ? ((shown.c - prevClose) / prevClose) * 100 : 0

  return (
    <div className={`chart ${mini ? 'mini' : ''}`} ref={wrap}>
      {shown && !mini && (
        <div className="ohlc num" aria-live="off">
          <span className="mute">{String(shown.t)}</span>
          <span>시가 <b>{fmt(shown.o)}</b></span>
          <span>고가 <b className="up">{fmt(shown.h)}</b></span>
          <span>저가 <b className="down">{fmt(shown.l)}</b></span>
          <span>종가 <b className={tone(chg)}>{fmt(shown.c)}</b></span>
          <span className={tone(chg)}>({rate(chg)})</span>
          <span className="mute">거래량 {shown.v.toLocaleString('ko-KR')}</span>
          <span className="legend">
            {MAS.map(([n, color], m) => (
              <span key={n} style={{ color }}>
                {n}일 {mas[m][globalIdx] != null ? fmt(mas[m][globalIdx]) : '-'}
              </span>
            ))}
          </span>
        </div>
      )}
      <canvas
        ref={cv}
        role="img"
        aria-label="캔들 차트"
        style={{ width: '100%', height, cursor: drag.current ? 'grabbing' : 'crosshair' }}
        onMouseMove={onMove}
        onMouseLeave={() => {
          setHover(null)
          drag.current = null
        }}
        onMouseDown={(e) => {
          drag.current = { x: e.clientX - cv.current.getBoundingClientRect().left, offset }
        }}
        onMouseUp={() => (drag.current = null)}
      />
    </div>
  )
}
