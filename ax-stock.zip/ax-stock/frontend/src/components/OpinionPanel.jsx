import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { api } from '../api.js'
import { rate, tone, won } from '../format.js'
import { HeartButton, Logo, WatchChip } from './HeartButton.jsx'

// 의견 5단계: 이름, 클래스(색은 CSS 변수), 응답 필드
const LEVELS = [
  ['적극매수', 'sb', 'strong_buy'],
  ['매수', 'b', 'buy'],
  ['중립', 'h', 'hold'],
  ['매도', 's', 'sell'],
  ['적극매도', 'ss', 'strong_sell'],
]

// 반원 게이지: 0(적극매도, 파랑) → 100(적극매수, 빨강)
function Gauge({ score, label }) {
  const cx = 80
  const cy = 82
  const r = 62
  const theta = Math.PI * (1 - score / 100)
  const dx = cx + r * Math.cos(theta)
  const dy = cy - r * Math.sin(theta)
  return (
    <svg viewBox="0 0 160 118" className="gauge" role="img" aria-label={`투자의견 ${label}, ${score}점`}>
      <defs>
        <linearGradient id="gauge-grad" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="var(--op-ss)" />
          <stop offset="0.5" stopColor="#9a78e6" />
          <stop offset="1" stopColor="var(--op-sb)" />
        </linearGradient>
      </defs>
      <path d={`M${cx - r},${cy} A${r},${r} 0 0 1 ${cx + r},${cy}`} fill="none" stroke="url(#gauge-grad)" strokeWidth="14" strokeLinecap="round" />
      <circle cx={dx} cy={dy} r="5.5" fill="#fff" stroke="var(--line)" strokeWidth="1.5" />
      <text x={cx} y="40" textAnchor="middle" className="gauge-tick">50</text>
      <text x={cx - r} y={cy + 20} textAnchor="middle" className="gauge-tick">0</text>
      <text x={cx + r} y={cy + 20} textAnchor="middle" className="gauge-tick">100</text>
      <text x={cx} y={cy - 6} textAnchor="middle" className="gauge-score">{Math.round(score)}</text>
      <text x={cx} y={cy + 14} textAnchor="middle" className="gauge-label">{label}</text>
    </svg>
  )
}

/**
 * 전문가 투자의견 패널 (적극매수 · 매수 · 중립 · 매도 · 적극매도)
 * header=true 이면 위에 종목 이름·현재가·하트를 같이 보여줘요.
 */
export default function OpinionPanel({ code, header = true }) {
  const [stock, setStock] = useState(null)
  const [op, setOp] = useState(null)
  const [analysis, setAnalysis] = useState(null)
  const [failed, setFailed] = useState(false)

  useEffect(() => {
    let alive = true
    setFailed(false)
    Promise.all([api.stock(code), api.opinion(code), api.analysis(code)])
      .then(([s, o, a]) => {
        if (!alive) return
        setStock(s)
        setOp(o)
        setAnalysis(a)
      })
      .catch(() => alive && setFailed(true))
    return () => {
      alive = false
    }
  }, [code])

  if (failed) return <p className="table-empty">투자의견을 불러오지 못했어요.</p>
  if (!stock || !op || stock.code !== code || op.code !== code) return <p className="panel-loading">불러오는 중…</p>

  const total = op.total || 1
  const pct = (n) => (n / total) * 100
  const sellSide = op.sell + op.strong_sell

  // 목표주가 범위 막대에서 현재가·평균 위치(%)
  const lo = Math.min(op.target_low, op.price)
  const hi = Math.max(op.target_high, op.price)
  const at = (v) => `${Math.min(100, Math.max(0, ((v - lo) / (hi - lo || 1)) * 100))}%`

  return (
    <div className="opinion">
      {header && (
        <div className="op-head">
          <Logo stock={stock} size={34} />
          <div className="grow">
            <div className="op-title">
              {stock.name} <span className="mute small num">{stock.code}</span> <WatchChip stock={stock} />
            </div>
            <div className="num">
              {won(stock.price)} <span className={tone(stock.change_rate)}>{rate(stock.change_rate)}</span>
            </div>
          </div>
          <HeartButton stock={stock} />
          <Link to={`/stock/${stock.code}`} className="op-link">차트·호가 보기 ›</Link>
        </div>
      )}

      <div className="op-grid">
        <section aria-label="종합 의견">
          <h3>종합 투자의견</h3>
          <Gauge score={op.score} label={op.label} />
        </section>

        <section aria-label="전문가 의견 수">
          <h3>
            전문가 투자의견 <span className="op-big num">{op.buy_pct.toFixed(0)}%</span>
          </h3>
          <div className="mute small">전문가 {op.total}명 중 매수 의견</div>
          <div className="op-split" aria-hidden="true">
            <i className="b" style={{ width: `${pct(op.strong_buy + op.buy)}%` }} />
            <i className="h" style={{ width: `${pct(op.hold)}%` }} />
            <i className="s" style={{ width: `${pct(sellSide)}%` }} />
          </div>
          <ul className="op-list">
            {LEVELS.map(([name, cls, key]) => (
              <li key={key}>
                <span className={`dot ${cls}`} />
                <span className={cls === 'h' ? '' : `op-text ${cls}`}>{name}</span>
                <b className={`num ${cls === 'h' ? 'mute' : `op-text ${cls}`}`}>{op[key]}</b>
              </li>
            ))}
          </ul>
        </section>

        <section aria-label="의견 분포와 목표주가">
          <h3>
            의견 분포 <span className="op-big">{op.label}</span>
          </h3>
          <div className="op-stack" aria-hidden="true">
            {LEVELS.map(([name, cls, key]) => op[key] > 0 && <i key={key} className={cls} style={{ width: `${pct(op[key])}%` }} />)}
          </div>
          <div className="op-legend">
            {LEVELS.map(([name, cls]) => (
              <span key={name}><span className={`dot ${cls}`} />{name}</span>
            ))}
          </div>

          <h3 className="op-sub">
            평균 목표주가 <span className="op-big num">{won(op.target_avg)}</span>
          </h3>
          <div className="range" aria-hidden="true">
            <i className="range-avg" style={{ left: at(op.target_avg) }} />
            <i className="range-now" style={{ left: at(op.price) }} />
          </div>
          <div className="range-labels num">
            <span>최저 {won(op.target_low)}</span>
            <span className={tone(op.upside_pct)}>상승여력 {op.upside_pct > 0 ? '+' : ''}{op.upside_pct.toFixed(1)}%</span>
            <span>최고 {won(op.target_high)}</span>
          </div>
        </section>
      </div>

      {analysis && (
        <p className="op-ai">
          <span className="badge">AI 분석</span> {analysis.headline}. {analysis.reasons[0]}
        </p>
      )}
      <p className="mute small op-note">전문가 의견 수와 목표주가는 개발용 샘플 데이터예요 · 기준일 {op.updated}</p>
    </div>
  )
}
