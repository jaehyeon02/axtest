import { useEffect, useRef, useState } from 'react'
import { Link, NavLink, useNavigate } from 'react-router-dom'
import { api } from '../api.js'
import { rate, tone, won } from '../format.js'
import StyleMenu from './StyleMenu.jsx'

export default function Header() {
  const [q, setQ] = useState('')
  const [results, setResults] = useState([])
  const [open, setOpen] = useState(false)
  const box = useRef(null)
  const input = useRef(null)
  const navigate = useNavigate()

  // 입력이 멈추면 0.25초 뒤에 검색합니다.
  useEffect(() => {
    if (!q.trim()) {
      setResults([])
      return
    }
    const timer = setTimeout(() => {
      api.stocks({ q, limit: 6 }).then(setResults).catch(() => setResults([]))
    }, 250)
    return () => clearTimeout(timer)
  }, [q])

  useEffect(() => {
    const close = (e) => box.current && !box.current.contains(e.target) && setOpen(false)
    document.addEventListener('mousedown', close)
    return () => document.removeEventListener('mousedown', close)
  }, [])

  // Alt+K 로 검색창에 바로 이동, Esc 로 닫기
  useEffect(() => {
    const onKey = (e) => {
      if (e.altKey && e.code === 'KeyK') {
        e.preventDefault()
        input.current?.focus()
        setOpen(true)
      }
      if (e.key === 'Escape') {
        setOpen(false)
        input.current?.blur()
      }
    }
    document.addEventListener('keydown', onKey)
    return () => document.removeEventListener('keydown', onKey)
  }, [])

  const go = (code) => {
    setOpen(false)
    setQ('')
    navigate(`/stock/${code}`)
  }

  return (
    <header className="top">
      <Link to="/" className="brand">
        AX<b>증권</b>
      </Link>
      <nav>
        <NavLink to="/" end>
          홈
        </NavLink>
      </nav>
      <div className="search" ref={box}>
        <svg viewBox="0 0 24 24" className="search-ico" aria-hidden="true"><circle cx="11" cy="11" r="6.5" /><path d="M16 16l4.5 4.5" /></svg>
        <input
          id="search"
          ref={input}
          type="search"
          value={q}
          placeholder="종목명·종목코드 입력 (단축키 Alt+K)"
          autoComplete="off"
          onChange={(e) => {
            setQ(e.target.value)
            setOpen(true)
          }}
          onFocus={() => setOpen(true)}
          onKeyDown={(e) => e.key === 'Enter' && results[0] && go(results[0].code)}
        />
        {open && q.trim() && (
          <ul className="search-list">
            {results.length === 0 && <li className="empty">검색 결과가 없어요</li>}
            {results.map((s) => (
              <li key={s.code}>
                <button type="button" onClick={() => go(s.code)}>
                  <span>{s.name}</span>
                  <span className="num mute">{won(s.price)}</span>
                  <span className={`num ${tone(s.change_rate)}`}>{rate(s.change_rate)}</span>
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>
      <div className="grow" />
      <StyleMenu />
      <span className="me-gap" aria-hidden="true" />
      <button type="button" className="login" disabled title="로그인은 추후 구현 예정">
        로그인
      </button>
    </header>
  )
}
