import { Link } from 'react-router-dom'
import { rate, tone, won } from '../format.js'
import { HeartButton, Logo } from './HeartButton.jsx'
import { useWatchlist } from '../hooks/useWatchlist.jsx'

// 오른쪽 "관심 주식" 패널. 하트를 누르기 전에는 안내 문구만 보여요.
// onSelect 를 넘기면(홈) 종목을 눌렀을 때 아래 투자의견이 열리고, 없으면 상세 페이지로 이동해요.
export default function WatchlistSidebar({ onSelect, selected }) {
  const { items, loaded } = useWatchlist()

  return (
    <aside className="card watch" aria-label="관심 주식">
      <div className="watch-head">
        <h2>관심 주식</h2>
        <span className="mute small">{items.length ? `${items.length}개` : '관심 그룹에 담아보세요'}</span>
      </div>

      {loaded && items.length === 0 && (
        <div className="watch-empty">
          <svg viewBox="0 0 24 24" aria-hidden="true">
            <path
              d="M12 20.5s-7.5-4.6-9.2-9.4C1.7 7.8 3.6 4.8 6.8 4.8c2 0 3.5 1.1 5.2 3 1.7-1.9 3.2-3 5.2-3 3.2 0 5.1 3 4 6.3-1.7 4.8-9.2 9.4-9.2 9.4z"
              strokeLinejoin="round"
            />
          </svg>
          <b>아직 관심 주식이 없어요</b>
          <span>종목 옆 하트를 누르면 여기에 모아서 볼 수 있어요.</span>
        </div>
      )}

      <ul className="watch-list">
        {items.map((s) => {
          const body = (
            <>
              <Logo stock={s} size={34} />
              <span className="watch-name">
                <span>{s.name}</span>
                <span className="mute small num">{s.code}</span>
              </span>
              <span className="watch-price">
                <span className="num">{won(s.price)}</span>
                <span className={`num small ${tone(s.change_rate)}`}>{rate(s.change_rate)}</span>
              </span>
            </>
          )
          return (
            <li key={s.code} aria-current={selected === s.code}>
              {onSelect ? (
                <button type="button" className="watch-row" onClick={() => onSelect(s.code)}>{body}</button>
              ) : (
                <Link to={`/stock/${s.code}`} className="watch-row">{body}</Link>
              )}
              <HeartButton stock={s} />
            </li>
          )
        })}
      </ul>
    </aside>
  )
}
