import { useEffect, useRef, useState } from 'react'
import { STYLES, useProfile } from '../hooks/useProfile.jsx'

// 로그인 왼쪽의 투자성향 선택. 고르면 추천 종목과 상세 설명이 그 성향에 맞게 바뀌어요.
export default function StyleMenu() {
  const { style, setStyle } = useProfile()
  const [open, setOpen] = useState(false)
  const box = useRef(null)

  useEffect(() => {
    const close = (e) => box.current && !box.current.contains(e.target) && setOpen(false)
    const esc = (e) => e.key === 'Escape' && setOpen(false)
    document.addEventListener('mousedown', close)
    document.addEventListener('keydown', esc)
    return () => {
      document.removeEventListener('mousedown', close)
      document.removeEventListener('keydown', esc)
    }
  }, [])

  return (
    <div className="style-menu" ref={box}>
      <button type="button" className="style-btn" aria-haspopup="listbox" aria-expanded={open} onClick={() => setOpen(!open)}>
        <span className="mute small">투자성향</span>
        <b>{STYLES[style].name}</b>
        <svg viewBox="0 0 12 12" aria-hidden="true"><path d="M2.5 4.5L6 8l3.5-3.5" /></svg>
      </button>
      {open && (
        <ul className="style-list" role="listbox" aria-label="투자성향">
          {Object.entries(STYLES).map(([k, v]) => (
            <li key={k}>
              <button
                type="button"
                role="option"
                aria-selected={style === k}
                onClick={() => {
                  setStyle(k)
                  setOpen(false)
                }}
              >
                <b>{v.name}</b>
                <span className="mute small">{v.desc}</span>
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}
