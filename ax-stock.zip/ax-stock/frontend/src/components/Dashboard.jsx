import { useEffect, useState } from 'react'
import { api } from '../api.js'
import { eok, pct, shares, tone, won } from '../format.js'
import { STYLES, useProfile } from '../hooks/useProfile.jsx'
import OpinionPanel from './OpinionPanel.jsx'
import PriceBand from './PriceBand.jsx'

const STATUS = { good: '좋아요', neutral: '보통', bad: '조심' }
const ICON = { flow: '📈', heat: '🔥', supply: '🐘', expert: '🎓' }

const GLOSSARY = [
  ['52주 최저·최고', '지난 1년 동안 가장 쌌던 가격과 가장 비쌌던 가격이에요.'],
  ['거래 열기', '평소보다 몇 배나 거래됐는지 보여줘요. 1배보다 크면 관심이 늘었다는 뜻이에요.'],
  ['외국인·기관', '자금이 큰 투자자예요. 이들이 사는 쪽이면 주가에 힘이 실리는 경우가 많아요.'],
  ['목표주가', '증권사 전문가들이 앞으로 이 정도까지 오를 수 있다고 본 가격이에요.'],
  ['적극매수~적극매도', '전문가 의견을 5단계로 나눈 말이에요. 매수 쪽일수록 좋게 본다는 뜻이에요.'],
]

// 초보자용 "한눈에 보기" 대시보드: 말로 된 요약 → 신호등 → 가격 위치 → 기간별 수익 → 만약 시뮬레이션 → 전문가 의견
export default function Dashboard({ code, stock }) {
  const { style } = useProfile()
  const [d, setD] = useState(null)
  const [failed, setFailed] = useState(false)

  useEffect(() => {
    setD(null)
    setFailed(false)
    api.dashboard(code).then(setD).catch(() => setFailed(true))
  }, [code])

  if (failed) return <p className="table-empty">요약 정보를 불러오지 못했어요.</p>
  if (!d) return <p className="panel-loading">불러오는 중…</p>

  const maxPeriod = Math.max(5, ...d.periods.map((p) => Math.abs(p.pct ?? 0)))
  const heatAt = Math.min(100, (d.heat.volume_ratio / 2) * 100) // 0배~2배 이상
  const net = [
    ['개인', d.net5.individual],
    ['외국인', d.net5.foreign],
    ['기관', d.net5.institution],
  ]
  const maxNet = Math.max(1, ...net.map(([, v]) => Math.abs(v)))
  const sim = d.simulation
  const high = d.pos52 >= 67
  const low = d.pos52 < 33
  const fit = {
    safe: high
      ? '1년 중 비싼 쪽이라, 한 번에 사기보다 나눠서 사는 방법도 있어요.'
      : '가격 부담이 크지 않은 구간이에요. 그래도 한 번에 몰아서 사지는 마세요.',
    normal: high
      ? '가격이 높은 편이니 전문가 의견과 거래 열기도 함께 확인해 보세요.'
      : low
        ? '가격이 낮은 편이에요. 낮은 데는 이유가 있을 수 있어 신호등을 같이 보세요.'
        : '가격이 중간쯤이에요. 신호등 4개를 같이 보고 판단해 보세요.',
    bold: low
      ? '가격이 낮은 구간이라 반등을 노려볼 수 있지만, 더 내릴 수도 있어요.'
      : '출렁임이 클수록 수익도 손실도 커져요. 넣는 금액을 정해 두세요.',
  }[style]

  return (
    <div className="dash">
      <section className="card dash-summary">
        <h2>
          <span className="dash-emoji" aria-hidden="true">💬</span> 3줄 요약
        </h2>
        <ol>
          {d.summary.map((t, i) => (
            <li key={i}>{t}</li>
          ))}
        </ol>
        <p className="fit">
          <b>{STYLES[style].name}</b> 성향이라면? {fit}
        </p>
        <p className="mute small">샘플 데이터로 만든 규칙 기반 설명이에요. 투자 권유가 아니에요.</p>
      </section>

      <section className="dash-signals" aria-label="신호등">
        {d.signals.map((s) => (
          <article key={s.key} className={`card signal ${s.status}`}>
            <div className="signal-head">
              <span aria-hidden="true">{ICON[s.key]}</span>
              <b>{s.title}</b>
              <span className={`light ${s.status}`}>
                <i /> {STATUS[s.status]}
              </span>
            </div>
            <p>{s.text}</p>
          </article>
        ))}
      </section>

      <div className="dash-cols">
        <section className="card dash-box">
          <h2>지금 가격, 비싼 걸까요?</h2>
          <PriceBand low={d.low52} high={d.high52} pos={d.pos52} />
          <p className="mute small">
            현재가 <b className="num">{won(stock.price)}</b> · 1년 동안의 가장 싼 값과 비싼 값 사이에서 보는 위치예요.
          </p>
        </section>

        <section className="card dash-box">
          <h2>기간별로 얼마나 움직였나요?</h2>
          <ul className="pbars">
            {d.periods.map((p) => {
              const w = (Math.abs(p.pct ?? 0) / maxPeriod) * 50
              return (
                <li key={p.label}>
                  <span className="mute small">{p.label}</span>
                  <div className="pbar-track">
                    <i
                      className={`pbar ${tone(p.pct)}`}
                      style={p.pct >= 0 ? { left: '50%', width: `${w}%` } : { right: '50%', width: `${w}%` }}
                    />
                  </div>
                  <b className={`num ${tone(p.pct)}`}>{pct(p.pct)}</b>
                </li>
              )
            })}
          </ul>
        </section>

        <section className="card dash-box sim">
          <h2>1년 전에 샀다면?</h2>
          <p className="sim-line">
            <span className="mute small">{won(sim.invested)}을 넣었다면 지금</span>
            <b className={`sim-value num ${tone(sim.pct)}`}>{won(sim.value)}</b>
            <span className={`num ${tone(sim.pct)}`}>
              {sim.value >= sim.invested ? '+' : '-'}
              {won(Math.abs(sim.value - sim.invested))} ({pct(sim.pct)})
            </span>
          </p>
          <p className="mute small">과거 결과일 뿐, 앞으로를 보장하지 않아요.</p>
        </section>

        <section className="card dash-box">
          <h2>오늘 분위기</h2>
          <div className="heat" role="img" aria-label={`평소의 ${d.heat.volume_ratio}배 거래`}>
            <div className="heat-track">
              <i className="heat-dot" style={{ left: `${heatAt}%` }} />
            </div>
            <div className="heat-labels small mute">
              <span>한산</span>
              <span>평소</span>
              <span>뜨거움</span>
            </div>
          </div>
          <dl className="heat-facts">
            <div><dt>평소 대비 거래</dt><dd className="num">{d.heat.volume_ratio.toFixed(1)}배</dd></div>
            <div><dt>거래대금 순위</dt><dd className="num">{d.heat.value_rank}위</dd></div>
            <div><dt>사자 호가 비중</dt><dd className="num">{d.heat.buy_ratio}%</dd></div>
          </dl>
        </section>

        <section className="card dash-box dash-wide">
          <h2>누가 사고 있나요? <span className="mute small">최근 5일 순매수(주)</span></h2>
          <ul className="nbars">
            {net.map(([name, v]) => (
              <li key={name}>
                <span>{name}</span>
                <div className="pbar-track">
                  <i
                    className={`pbar ${tone(v)}`}
                    style={v >= 0 ? { left: '50%', width: `${(Math.abs(v) / maxNet) * 50}%` } : { right: '50%', width: `${(Math.abs(v) / maxNet) * 50}%` }}
                  />
                </div>
                <b className={`num ${tone(v)}`}>{v > 0 ? '사는 쪽 ' : v < 0 ? '파는 쪽 ' : ''}{shares(v)}</b>
              </li>
            ))}
          </ul>
        </section>
      </div>

      <section className="card dash-opinion">
        <h2>전문가들은 어떻게 볼까요?</h2>
        <OpinionPanel code={code} header={false} />
      </section>

      <section className="card dash-gloss">
        <h2>용어 사전</h2>
        <dl>
          {GLOSSARY.map(([k, v]) => (
            <div key={k}>
              <dt>{k}</dt>
              <dd>{v}</dd>
            </div>
          ))}
        </dl>
      </section>
    </div>
  )
}
