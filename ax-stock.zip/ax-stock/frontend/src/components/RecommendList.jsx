import { useEffect, useState } from 'react'
import { api } from '../api.js'
import { rate, tone, won } from '../format.js'
import { HeartButton, Logo } from './HeartButton.jsx'
import { STYLES, useProfile } from '../hooks/useProfile.jsx'

const MARKETS = [
  ['all', '전체'],
  ['kr', '국내'],
  ['us', '해외'],
]
const LABEL_CLASS = { 적극매수: 'sb', 매수: 'b', 중립: 'h', 매도: 's', 적극매도: 'ss' }

// 오른쪽 관심 주식 아래에 놓이는 "추천 종목". 전문가 투자의견 점수가 높은 순서예요.
export default function RecommendList({ onSelect, selected }) {
  const { style } = useProfile()
  const [market, setMarket] = useState('all')
  const [items, setItems] = useState([])
  const [failed, setFailed] = useState(false)

  useEffect(() => {
    setFailed(false)
    api.recommended(market, 5, style).then(setItems).catch(() => setFailed(true))
  }, [market, style])

  return (
    <aside className="card watch" id="recommend" aria-label="추천 종목">
      <div className="watch-head">
        <h2>추천 종목</h2>
        <div className="seg small-seg" role="group" aria-label="추천 종목 시장">
          {MARKETS.map(([k, name]) => (
            <button key={k} type="button" aria-pressed={market === k} onClick={() => setMarket(k)}>
              {name}
            </button>
          ))}
        </div>
      </div>
      <p className="mute small rec-note"><b>{STYLES[style].name}</b> 성향 · 전문가 점수가 높은 순이에요.</p>
      {failed && <p className="table-empty">추천 종목을 불러오지 못했어요.</p>}
      <ul className="watch-list">
        {items.map((s) => (
          <li key={s.code} aria-current={selected === s.code}>
            <button type="button" className="watch-row" onClick={() => onSelect(s.code)}>
              <Logo stock={s} size={34} />
              <span className="watch-name">
                <span>{s.name}</span>
                <span className={`op-label small ${LABEL_CLASS[s.label]}`}>
                  {s.label} <span className="mute num">· {s.total}명</span>
                </span>
              </span>
              <span className="watch-price">
                <span className="num">{won(s.price)}</span>
                <span className={`num small ${tone(s.change_rate)}`}>{rate(s.change_rate)}</span>
              </span>
            </button>
            <HeartButton stock={s} />
          </li>
        ))}
      </ul>
    </aside>
  )
}
