import { won, zone } from '../format.js'

// "1년 중 가격 위치" 막대: 1년 최저가(왼쪽)~최고가(오른쪽) 사이에서 현재가가 어디쯤인지 보여줘요.
// 그래프 대신 초보자도 바로 읽을 수 있도록 말로도 같이 알려줘요.
export default function PriceBand({ low, high, pos, compact = false }) {
  const at = Math.min(100, Math.max(0, pos))
  return (
    <div className={`band ${compact ? 'compact' : ''}`}>
      <div className="band-head">
        <span className="mute small">1년 중 가격 위치</span>
        <b className="band-zone">{zone(pos)}</b>
      </div>
      <div className="band-track" role="img" aria-label={`1년 중 ${Math.round(pos)}% 위치, ${zone(pos)}`}>
        <i className="band-fill" style={{ width: `${at}%` }} />
        <i className="band-dot" style={{ left: `${at}%` }} />
      </div>
      <div className="band-labels num small">
        <span>{compact ? '1년 최저' : `최저 ${won(low)}`}</span>
        <span>{compact ? '1년 최고' : `최고 ${won(high)}`}</span>
      </div>
    </div>
  )
}
