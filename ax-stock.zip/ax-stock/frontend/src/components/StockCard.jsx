import { pct, rate, tone, won } from '../format.js'
import { HeartButton, Logo, WatchChip } from './HeartButton.jsx'
import PriceBand from './PriceBand.jsx'

const LABEL_CLASS = { 적극매수: 'sb', 매수: 'b', 중립: 'h', 매도: 's', 적극매도: 'ss' }

// 홈의 관심 주식 카드. 그래프 대신 "1년 중 가격 위치"와 "기간별 수익률"로 보여줘요.
export default function StockCard({ stock, insight, selected, onSelect, comparing = false, onCompare }) {
  const diff = Math.abs(stock.price - stock.prev_close)
  const arrow = stock.change_rate > 0 ? '▲' : stock.change_rate < 0 ? '▼' : ''

  return (
    <article
      className="scard"
      tabIndex={0}
      aria-current={selected}
      onClick={() => onSelect(stock.code)}
      onKeyDown={(e) => (e.key === 'Enter' || e.key === ' ') && (e.preventDefault(), onSelect(stock.code))}
    >
      <div className="scard-top">
        <Logo stock={stock} size={26} />
        <span className="scard-name">{stock.name}</span>
        {onCompare && (
          <button
            type="button"
            className="cmp-chk"
            aria-pressed={comparing}
            title="비교하기 (최대 3개)"
            onClick={(e) => {
              e.stopPropagation()
              onCompare(stock.code)
            }}
            onKeyDown={(e) => e.stopPropagation()}
          >
            {comparing ? '✓ 비교' : '+ 비교'}
          </button>
        )}
        <HeartButton stock={stock} />
      </div>
      <div className="scard-mid">
        <WatchChip stock={stock} />
        <div className="scard-price">
          <b className="num">{won(stock.price)}</b>
          <span className={`num small ${tone(stock.change_rate)}`}>
            {arrow} {won(diff)} ({rate(stock.change_rate)})
          </span>
        </div>
      </div>

      {insight ? (
        <>
          <PriceBand low={insight.low52} high={insight.high52} pos={insight.pos52} compact />
          <div className="rets">
            {[
              ['1주', insight.ret_1w],
              ['1개월', insight.ret_1m],
              ['3개월', insight.ret_3m],
            ].map(([name, v]) => (
              <div key={name}>
                <span className="mute small">{name}</span>
                <b className={`num ${tone(v)}`}>{pct(v)}</b>
              </div>
            ))}
          </div>
          {insight.op_label && (
            <div className="scard-op">
              <span className="mute small">전문가 의견</span>
              <span className={`op-label ${LABEL_CLASS[insight.op_label]}`}>{insight.op_label}</span>
              <span className="mute small num">{insight.op_total}명</span>
            </div>
          )}
        </>
      ) : (
        <div className="spark-empty" style={{ height: 96 }} />
      )}
    </article>
  )
}
