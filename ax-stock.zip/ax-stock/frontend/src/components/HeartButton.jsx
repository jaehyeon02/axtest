import { useWatchlist } from '../hooks/useWatchlist.jsx'

const HEART =
  'M12 20.5s-7.5-4.6-9.2-9.4C1.7 7.8 3.6 4.8 6.8 4.8c2 0 3.5 1.1 5.2 3 1.7-1.9 3.2-3 5.2-3 3.2 0 5.1 3 4 6.3-1.7 4.8-9.2 9.4-9.2 9.4z'

// 하트 버튼: 누르면 관심 종목에 담기고, 다시 누르면 빠져요.
export function HeartButton({ stock }) {
  const { codes, toggle } = useWatchlist()
  const on = codes.has(stock.code)
  return (
    <button
      type="button"
      className="heart"
      aria-pressed={on}
      aria-label={`${stock.name} ${on ? '관심 해제' : '관심 추가'}`}
      onClick={(e) => {
        e.stopPropagation()
        toggle(stock)
      }}
    >
      <svg viewBox="0 0 24 24" aria-hidden="true">
        <path d={HEART} strokeLinejoin="round" />
      </svg>
    </button>
  )
}

// 종목 이름 옆의 작은 표시. "관심없음" ↔ "관심" 을 눌러서 바꿀 수 있어요.
export function WatchChip({ stock }) {
  const { codes, toggle } = useWatchlist()
  const on = codes.has(stock.code)
  return (
    <button
      type="button"
      className="chip"
      aria-pressed={on}
      onClick={(e) => {
        e.stopPropagation()
        toggle(stock)
      }}
    >
      {on ? '관심' : '관심없음'}
    </button>
  )
}

export function Logo({ stock, size = 28 }) {
  return (
    <span
      className="logo-dot"
      style={{ background: stock.logo_color, width: size, height: size, fontSize: size * 0.38 }}
      aria-hidden="true"
    >
      {stock.logo_text}
    </span>
  )
}
