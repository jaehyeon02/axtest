import { useEffect, useState } from 'react'
import { api } from '../api.js'
import { pct, rate, tone, won, zone } from '../format.js'
import { Logo } from './HeartButton.jsx'

const SIGNAL = { good: '좋아요', neutral: '보통', bad: '조심' }
const SIGNAL_KEYS = [
  ['flow', '가격 흐름'],
  ['heat', '거래 열기'],
  ['supply', '큰손 움직임'],
  ['expert', '전문가 의견'],
]

// 받침 여부에 따라 조사를 골라요. (이/가, 으로/로)
const hasBatchim = (w) => {
  const c = w.charCodeAt(w.length - 1) - 0xac00
  return c >= 0 && c <= 11171 && c % 28 !== 0
}
const iga = (w) => `${w}${hasBatchim(w) ? '이' : '가'}`

// 가장 큰 값의 칸 번호(동점·값 없음은 제외). 표에서 "여기가 제일 좋아요" 표시에 써요.
function best(values) {
  const nums = values.map((v) => (typeof v === 'number' ? v : -Infinity))
  const top = Math.max(...nums)
  return top === -Infinity || nums.filter((n) => n === top).length > 1 ? -1 : nums.indexOf(top)
}

// 관심 주식 2~3개를 같은 항목으로 나란히 보여주는 비교 표. 초보자용이라 "누가 더 큰지"를 말로도 알려줘요.
export default function Compare({ stocks, onRemove }) {
  const [data, setData] = useState({})
  const [failed, setFailed] = useState(false)
  const key = stocks.map((s) => s.code).join(',')

  useEffect(() => {
    let alive = true
    setFailed(false)
    Promise.all(stocks.map((s) => Promise.all([api.dashboard(s.code), api.opinion(s.code)])))
      .then((rows) => {
        if (!alive) return
        const m = {}
        stocks.forEach((s, i) => (m[s.code] = { d: rows[i][0], o: rows[i][1] }))
        setData(m)
      })
      .catch(() => alive && setFailed(true))
    return () => {
      alive = false
    }
  }, [key]) // eslint-disable-line react-hooks/exhaustive-deps

  const ready = stocks.every((s) => data[s.code])
  if (failed) return <p className="table-empty">비교 정보를 불러오지 못했어요.</p>
  if (!ready) return <p className="panel-loading">불러오는 중…</p>

  const get = (s) => data[s.code]
  const periodLabels = get(stocks[0]).d.periods.map((p) => p.label)
  const ret = (s, label) => get(s).d.periods.find((p) => p.label === label)?.pct ?? null
  const year = stocks.map((s) => ret(s, '1년'))
  const score = stocks.map((s) => get(s).o.score)
  const upside = stocks.map((s) => get(s).o.upside_pct)
  const name = (i) => stocks[i].name

  const lines = []
  let i = best(year)
  if (i >= 0)
    lines.push(
      year[i] >= 0
        ? `1년 수익률은 ${iga(name(i))} ${pct(year[i])}로 가장 높았어요.`
        : `1년 동안 ${iga(name(i))} ${pct(year[i])}로 가장 덜 떨어졌어요.`,
    )
  i = best(score)
  if (i >= 0) lines.push(`전문가 의견은 ${iga(name(i))} '${get(stocks[i]).o.label}'(으)로 가장 좋아요.`.replace('(으)로', hasBatchim(get(stocks[i]).o.label) ? '으로' : '로'))
  i = best(upside)
  if (i >= 0) lines.push(`목표주가까지 여유는 ${iga(name(i))} ${pct(upside[i])}로 가장 커요.`)

  const Row = ({ label, cells, win = -1, hint }) => (
    <tr>
      <th scope="row">
        {label}
        {hint && <span className="mute small">{hint}</span>}
      </th>
      {cells.map((c, k) => (
        <td key={stocks[k].code} className={k === win ? 'win' : ''}>
          {c}
        </td>
      ))}
    </tr>
  )

  return (
    <div className="card cmp">
      <div className="cmp-scroll">
        <table>
          <thead>
            <tr>
              <th />
              {stocks.map((s) => (
                <th key={s.code} scope="col">
                  <div className="cmp-head">
                    <Logo stock={s} size={28} />
                    <b>{s.name}</b>
                    <button type="button" className="cmp-x" aria-label={`${s.name} 비교에서 빼기`} onClick={() => onRemove(s.code)}>
                      ×
                    </button>
                  </div>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            <Row
              label="현재가"
              cells={stocks.map((s) => (
                <>
                  <b className="num">{won(s.price)}</b>
                  <span className={`num small ${tone(s.change_rate)}`}> {rate(s.change_rate)}</span>
                </>
              ))}
            />
            <Row
              label="1년 중 가격 위치"
              cells={stocks.map((s) => {
                const p = Math.min(100, Math.max(0, get(s).d.pos52))
                return (
                  <div className="cmp-pos">
                    <div className="band-track">
                      <i className="band-fill" style={{ width: `${p}%` }} />
                      <i className="band-dot" style={{ left: `${p}%` }} />
                    </div>
                    <b className="band-zone">{zone(get(s).d.pos52)}</b>
                  </div>
                )
              })}
            />
            {periodLabels.map((label) => {
              const vals = stocks.map((s) => ret(s, label))
              return (
                <Row
                  key={label}
                  label={`${label} 수익률`}
                  win={best(vals)}
                  cells={vals.map((v) => <b className={`num ${tone(v)}`}>{pct(v)}</b>)}
                />
              )
            })}
            <Row
              label="1년 전 100만원이면"
              win={best(stocks.map((s) => get(s).d.simulation.value))}
              cells={stocks.map((s) => <b className="num">{won(get(s).d.simulation.value)}</b>)}
            />
            <Row
              label="전문가 의견"
              win={best(score)}
              cells={stocks.map((s) => (
                <>
                  <b>{get(s).o.label}</b> <span className="mute small">{get(s).o.total}명</span>
                </>
              ))}
            />
            <Row
              label="목표주가 여유"
              hint="평균 목표가 기준"
              win={best(upside)}
              cells={upside.map((v) => <b className={`num ${tone(v)}`}>{pct(v)}</b>)}
            />
            {SIGNAL_KEYS.map(([k, title]) => (
              <Row
                key={k}
                label={title}
                cells={stocks.map((s) => {
                  const sig = get(s).d.signals.find((x) => x.key === k)
                  return sig ? (
                    <span className={`light ${sig.status}`}>
                      <i /> {SIGNAL[sig.status]}
                    </span>
                  ) : (
                    '-'
                  )
                })}
              />
            ))}
          </tbody>
        </table>
      </div>
      {lines.length > 0 && (
        <ul className="cmp-sum">
          {lines.map((l) => (
            <li key={l}>{l}</li>
          ))}
        </ul>
      )}
      <p className="mute small cmp-note">초록 칸이 그 항목에서 가장 좋은 쪽이에요. 과거 결과와 샘플 데이터라 어느 쪽을 사라는 뜻은 아니에요.</p>
    </div>
  )
}
