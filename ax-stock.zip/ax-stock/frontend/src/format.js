export const won = (n) => `${Math.round(n).toLocaleString('ko-KR')}원`

export const rate = (r) => `${r > 0 ? '+' : r < 0 ? '-' : ''}${Math.abs(r).toFixed(2)}%`

// 등락 방향 → CSS 클래스. 한국 증권 앱처럼 상승은 빨강, 하락은 파랑입니다.
export const tone = (r) => (r > 0 ? 'up' : r < 0 ? 'down' : 'flat')

// 억원 단위 숫자를 "1,344.8조원" / "161억원" 으로 바꿔요.
export function eok(n) {
  if (n >= 10000) {
    return `${(n / 10000).toLocaleString('ko-KR', { minimumFractionDigits: 1, maximumFractionDigits: 1 })}조원`
  }
  return n >= 10 ? `${Math.round(n).toLocaleString('ko-KR')}억원` : `${n.toFixed(1)}억원`
}

export const shares = (n) => `${n < 0 ? '-' : ''}${Math.abs(n).toLocaleString('ko-KR')}`

// 국내 주식 호가 단위(원)
export function tickSize(price) {
  if (price < 2000) return 1
  if (price < 5000) return 5
  if (price < 20000) return 10
  if (price < 50000) return 50
  if (price < 200000) return 100
  if (price < 500000) return 500
  return 1000
}

// 부호가 붙은 퍼센트 문자열. 값이 없으면 '-'
export const pct = (v) => (v == null ? '-' : `${v > 0 ? '+' : ''}${v.toFixed(1)}%`)

// 1년 가격 위치(0~100)를 쉬운 말로 바꿔요.
export function zone(pos) {
  if (pos >= 67) return '높은 편'
  if (pos < 33) return '낮은 편'
  return '중간쯤'
}
