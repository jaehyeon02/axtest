// 백엔드 호출 모음. 화면 코드는 fetch를 직접 쓰지 않고 여기 함수만 부릅니다.

// 로그인이 없으니 브라우저마다 임시 ID를 만들어 관심 종목을 구분해요.
export function clientId() {
  try {
    let id = localStorage.getItem('ax-client-id')
    if (!id) {
      id = crypto.randomUUID()
      localStorage.setItem('ax-client-id', id)
    }
    return id
  } catch {
    return 'anonymous'
  }
}

async function request(path, options = {}) {
  const res = await fetch(path, {
    ...options,
    headers: { 'X-Client-Id': clientId(), ...(options.headers || {}) },
  })
  if (!res.ok) throw new Error(`${res.status} ${path}`)
  return res.status === 204 ? null : res.json()
}

const qs = (params) => new URLSearchParams(params).toString()

export const api = {
  stocks: (params = {}) => request(`/api/stocks?${qs(params)}`),
  stock: (code) => request(`/api/stocks/${code}`),
  candles: (code, interval = 'D', limit = 600) =>
    request(`/api/stocks/${code}/candles?${qs({ interval, limit })}`),
  recommended: (market = 'all', limit = 6, style = 'normal') => request(`/api/stocks/recommended?${qs({ market, limit, style })}`),
  insights: (codes) => request(`/api/stocks/insights?${qs({ codes: codes.join(',') })}`),
  dashboard: (code) => request(`/api/stocks/${code}/dashboard`),
  opinion: (code) => request(`/api/stocks/${code}/opinion`),
  analysis: (code) => request(`/api/stocks/${code}/analysis`),
  news: (code) => request(`/api/stocks/${code}/news`),
  investors: (code) => request(`/api/stocks/${code}/investors`),
  watchlist: () => request('/api/watchlist'),
  addWatch: (code) => request(`/api/watchlist/${code}`, { method: 'PUT' }),
  removeWatch: (code) => request(`/api/watchlist/${code}`, { method: 'DELETE' }),
}
